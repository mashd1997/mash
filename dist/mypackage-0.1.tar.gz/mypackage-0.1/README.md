GOAT = 'Mashudu'
print(GOAT)
